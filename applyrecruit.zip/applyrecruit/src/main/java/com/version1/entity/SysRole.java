package com.version1.entity;

import lombok.Data;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @ClassName SysRole
 * @Description 角色实体
 * @Date 2018/4/11 19:38
 * @Version 1.0
 **/

@Entity
@Data
@DynamicUpdate
@DynamicInsert
public class SysRole implements Serializable {

    @Id
    @GeneratedValue
    private Integer id; // 编号
    @Column(length = 64)
    private String role; // 角色标识程序中判断使用,如"admin",这个是唯一的:
    private String description; // 角色描述,UI界面显示使用
    private Boolean available = Boolean.FALSE; // 是否可用,如果不可用将不会添加给用户

    @Column(columnDefinition = "timestamp null default CURRENT_TIMESTAMP")
    private Date createdTime;
    @Column(columnDefinition = "timestamp null default CURRENT_TIMESTAMP on update current_timestamp(0)")
    private Date updatedTime;

    //角色 -- 权限关系：多对多关系;
    @ManyToMany//(fetch= FetchType.EAGER)
    @JoinTable(name="SysRolePermission",joinColumns={@JoinColumn(name="roleId")},inverseJoinColumns={@JoinColumn(name="permissionId")})
    private List<SysPermission> permissions;

    // 用户 - 角色关系定义;
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "role")
    private List<UserInfo> userInfos;// 一个角色对应多个用户

}
