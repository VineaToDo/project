package com.version1.commons.enums;

public interface CodeEnum {
    Integer getCode();
}
