package com.version1.commons.exceptions;

/**
 * @ClassName ImageAcceptNotSupportException
 * @Description TODO
 * @Date 2018/5/31 14:05
 * @Version 1.0
 */
public class ImageAcceptNotSupportException extends Throwable {
}
