package com.version1.commons.exceptions;

/**
 * @ClassName ImageMaxSizeOverFlow
 * @Description TODO
 * @Date 2018/5/31 14:06
 * @Version 1.0
 */
public class ImageMaxSizeOverFlow extends Throwable {
}
