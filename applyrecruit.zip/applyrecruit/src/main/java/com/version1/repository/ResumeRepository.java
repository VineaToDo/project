package com.version1.repository;

import com.version1.entity.ResumeInfo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ResumeRepository extends JpaRepository<ResumeInfo,Integer> {




}