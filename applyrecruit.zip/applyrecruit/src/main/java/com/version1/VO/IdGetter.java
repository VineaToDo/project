package com.version1.VO;

public interface IdGetter {
    Integer getId();
}